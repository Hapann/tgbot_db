from telegram import Update, InputMediaPhoto, InputMediaDocument, InputMediaVideo, InputMediaAnimation
from telegram.ext import MessageHandler, filters, CallbackContext
from globals.config import GROUP_CHAT_ID, MAX_FILE_SIZE
from loger.logger import logger
from database import pool
import asyncpg

async def new_message_handler(update: Update, context: CallbackContext):
    user_id = update.effective_user.id
    username = update.effective_user.username or f"User_{user_id}"

    if update.message.chat.type != "private":
        return

    try:
        # Получаем thread_id из базы данных
        async with pool.acquire() as conn:
            thread_id = await conn.fetchval(
                "SELECT thread_id FROM users WHERE user_id = $1", 
                user_id
            )

        if not thread_id:
            await update.message.reply_text("Сначала создайте топик через /start")
            logger.warning(f"Попытка отправки без топика: {username}")
            return

        # Проверка прав доступа бота в группе
        try:
            chat = await context.bot.get_chat(GROUP_CHAT_ID)
            if not chat.permissions.can_send_messages:
                await update.message.reply_text("❌ Участники не могут отправлять сообщения в этот чат")
                return
            if getattr(chat, 'join_to_send_messages', False):
                chat_member = await context.bot.get_chat_member(GROUP_CHAT_ID, context.bot.id)
                if chat_member.status not in ["administrator", "member"]:
                    await update.message.reply_text("❌ Бот должен быть участником группы")
                    return
        except Exception as e:
            logger.error(f"Ошибка проверки чата: {e}")
            await update.message.reply_text("🚫 Ошибка проверки прав доступа")
            return

        # Обработка текстовых сообщений
        if update.message.text:
            try:
                await context.bot.send_message(
                    chat_id=GROUP_CHAT_ID,
                    text=update.message.text,
                    message_thread_id=thread_id,
                    parse_mode="HTML"
                )
                logger.info(f"Отправлен текст от {username}")
            except Exception as e:
                logger.error(f"Ошибка отправки текста: {e}")
                await update.message.reply_text("❌ Не удалось отправить текст")

        # Обработка медиагрупп
        if update.message.media_group_id:
            try:
                async with pool.acquire() as conn:
                    # Проверяем и добавляем медиагруппу в БД
                    exists = await conn.fetchval(
                        """INSERT INTO media_groups (media_group_id) 
                        VALUES ($1) 
                        ON CONFLICT (media_group_id) DO NOTHING 
                        RETURNING 1""",
                        update.message.media_group_id
                    )
                    if exists:
                        return

                # Получаем все сообщения медиагруппы
                media_messages = await context.bot.get_media_group(
                    chat_id=update.message.chat_id,
                    message_id=update.message.message_id
                )

                media = []
                for msg in media_messages:
                    # Проверка размера файла и формирование медиаобъектов
                    if msg.photo:
                        media.append(InputMediaPhoto(msg.photo[-1].file_id, caption=msg.caption))
                    elif msg.document:
                        if msg.document.file_size > MAX_FILE_SIZE:
                            await update.message.reply_text("Размер файла превышает 20MB.")
                            return
                        media.append(InputMediaDocument(msg.document.file_id, caption=msg.caption))
                    elif msg.video:
                        if msg.video.file_size > MAX_FILE_SIZE:
                            await update.message.reply_text("Размер видео превышает 20MB.")
                            return
                        media.append(InputMediaVideo(msg.video.file_id, caption=msg.caption))
                    elif msg.animation:
                        if msg.animation.file_size > MAX_FILE_SIZE:
                            await update.message.reply_text("Размер анимации превышает 20MB.")
                            return
                        media.append(InputMediaAnimation(msg.animation.file_id, caption=msg.caption))

                if len(media) > 10:
                    await update.message.reply_text("Медиагруппа не может содержать более 10 файлов.")
                    return

                # Отправка медиагруппы
                await context.bot.send_media_group(
                    chat_id=GROUP_CHAT_ID,
                    media=media,
                    message_thread_id=thread_id
                )
                logger.info(f"Отправлена медиагруппа от {username}")

            except asyncpg.PostgresError as pe:
                logger.error(f"Ошибка базы данных при обработке медиагруппы: {pe}")
            except Exception as e:
                logger.error(f"Ошибка обработки медиагруппы: {e}")
                await update.message.reply_text("❌ Ошибка обработки медиагруппы")

        # Обработка одиночных файлов
        content_handlers = {
            'photo': (context.bot.send_photo, 'photo[-1].file_id'),
            'document': (context.bot.send_document, 'document.file_id'),
            'video': (context.bot.send_video, 'video.file_id'),
            'audio': (context.bot.send_audio, 'audio.file_id'),
            'voice': (context.bot.send_voice, 'voice.file_id'),
            'sticker': (context.bot.send_sticker, 'sticker.file_id'),
            'animation': (context.bot.send_animation, 'animation.file_id'),
            'poll': (context.bot.send_poll, 'poll')
        }

        sent = False
        for content_type, (handler, attr) in content_handlers.items():
            content = getattr(update.message, content_type, None)
            if content:
                try:
                    # Проверка размера файла
                    if hasattr(content, 'file_size') and content.file_size > MAX_FILE_SIZE:
                        await update.message.reply_text("Размер файла превышает 20MB.")
                        return

                    # Отправка контента
                    await handler(
                        chat_id=GROUP_CHAT_ID,
                        **{content_type: eval(f'update.message.{attr}')},
                        message_thread_id=thread_id,
                        caption=update.message.caption
                    )
                    logger.info(f"Отправлен {content_type} от {username}")
                    sent = True
                    break
                except Exception as e:
                    logger.error(f"Ошибка отправки {content_type}: {e}")
                    await update.message.reply_text(f"❌ Ошибка отправки {content_type}")
                    return

        if not sent and not update.message.text and not update.message.media_group_id:
            logger.warning(f"Неподдерживаемый тип вложения от {username}")
            await update.message.reply_text("❌ Этот тип вложений не поддерживается")

    except asyncpg.PostgresError as pe:
        logger.error(f"Ошибка базы данных: {pe}")
        await update.message.reply_text("⚠️ Ошибка обработки запроса. Попробуйте позже.")
    except Exception as e:
        logger.error(f"Общая ошибка обработки сообщения: {e}", exc_info=True)
        await update.message.reply_text("⚠️ Произошла непредвиденная ошибка")