from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, filters
from globals.config import TOKEN
from handlers.start import start
from handlers.rules import rules_command
from handlers.messages import new_message_handler
from handlers.replies import handle_group_replies
from loger.logger import logger
from database import init_db

async def main():
    # Инициализация базы данных
    await init_db()
    
    # Создание приложения
    application = ApplicationBuilder().token(TOKEN).build()

    try:
        # Регистрация обработчиков
        application.add_handler(CommandHandler("start", start))
        application.add_handler(CommandHandler("rules", rules_command))
        application.add_handler(
            MessageHandler(filters.ChatType.PRIVATE, new_message_handler)
        )
        application.add_handler(MessageHandler(filters.REPLY, handle_group_replies))

        logger.info("Бот успешно инициализирован")
        await application.run_polling()

    except Exception as e:
        logger.critical(f"Критическая ошибка: {e}")
        raise

if __name__ == "__main__":
    import asyncio
    asyncio.run(main())