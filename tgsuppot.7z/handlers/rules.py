from telegram import Update
from telegram.ext import ContextTypes
from loger.logger import logger

async def rules_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    rules_text = (
        "Правила пользования ботом:\n"
        "1. Уважительно относиться к содержанию и беседе\n"
        "2. Не нарушать правила проведения турнира и законы РФ\n"
        "3. Вложения отправлять отдельно по 1 за раз без текста\n"
        "4. Текст направлять отдельно (ну мало ли)\n"
        "5. Терпеливо ожидать ответа на ваш запрос\n"
        "6. Не спамить и не просить дать флаг. Вам не ответят (только если за деньги)"
    )
    await update.message.reply_text(rules_text)
    logger.info(f"Отправлены правила пользователю {update.effective_user.id}")