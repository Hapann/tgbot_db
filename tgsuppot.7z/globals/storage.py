# Глобальные переменные
user_topics = {}
topic_to_user = {}
processed_media_groups = set()
message_map = {}
MAX_FILE_SIZE = 20 * 1024 * 1024  # 20MB