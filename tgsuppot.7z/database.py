import asyncpg
from globals.config import *

pool = None

async def init_db():
    global pool
    pool = await asyncpg.create_pool(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD,
        port=POSTGRES_PORT,
        min_size=5,
        max_size=20
    )
    
    async with pool.acquire() as conn:
        await conn.execute('''
            CREATE TABLE IF NOT EXISTS users (
                user_id BIGINT PRIMARY KEY,
                username TEXT,
                thread_id BIGINT UNIQUE
            )
        ''')
        await conn.execute('''
            CREATE TABLE IF NOT EXISTS message_map (
                group_message_id BIGINT PRIMARY KEY,
                user_message_id BIGINT
            )
        ''')
        await conn.execute('''
            CREATE TABLE IF NOT EXISTS media_groups (
                media_group_id TEXT PRIMARY KEY,
                expiration TIMESTAMP DEFAULT NOW() + INTERVAL '1 hour'
            )
        ''')

    return pool
    async def get_user(self, user_id):
        return await self.pool.fetchrow("SELECT * FROM users WHERE user_id = $1", user_id)

    async def create_user(self, user_id, username, thread_id):
        await self.pool.execute(
            "INSERT INTO users (user_id, username, thread_id) VALUES ($1, $2, $3)",
            user_id, username, thread_id
        )

    async def get_user_by_thread(self, thread_id):
        return await self.pool.fetchrow("SELECT * FROM users WHERE thread_id = $1", thread_id)

    async def add_message_mapping(self, group_message_id, user_message_id, user_id):
        await self.pool.execute(
            "INSERT INTO message_map (group_message_id, user_message_id, user_id) VALUES ($1, $2, $3)",
            group_message_id, user_message_id, user_id
        )

    async def get_message_mapping(self, group_message_id, user_id):
        return await self.pool.fetchval(
            "SELECT user_message_id FROM message_map WHERE group_message_id = $1 AND user_id = $2",
            group_message_id, user_id
        )

    async def check_media_group(self, media_group_id):
        return await self.pool.fetchrow("SELECT 1 FROM media_groups WHERE media_group_id = $1", media_group_id)

    async def mark_media_group(self, media_group_id):
        await self.pool.execute(
            "INSERT INTO media_groups (media_group_id) VALUES ($1) ON CONFLICT DO NOTHING",
            media_group_id
        )