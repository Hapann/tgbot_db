import os
import asyncpg
import time
from globals.config import *

async def wait_for_db():
    start_time = time.time()
    while time.time() - start_time < 30:
        try:
            conn = await asyncpg.connect(
                host=POSTGRES_HOST,
                database=POSTGRES_DB,
                user=POSTGRES_USER,
                password=POSTGRES_PASSWORD,
                port=POSTGRES_PORT
            )
            await conn.close()
            return True
        except Exception:
            time.sleep(1)
    return False

if __name__ == "__main__":
    import asyncio
    if not asyncio.run(wait_for_db()):
        exit(1)