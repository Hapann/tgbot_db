from telegram import Update, ReactionTypeEmoji
from telegram.ext import MessageHandler, filters, CallbackContext
from globals.storage import *
from globals.config import GROUP_CHAT_ID
from loger.logger import logger

async def handle_group_replies(update: Update, context: CallbackContext):
    """Обработчик ответов в группе с улучшенной фильтрацией"""
    sent = None  # Инициализация переменной
    success = True
    sent_types = []

    # Проверка базовых условий
    if not (update.message and update.message.reply_to_message):
        logger.debug("Сообщение не является ответом, игнорируем.")
        return

    if update.message.chat_id != GROUP_CHAT_ID:
        logger.debug("Сообщение не из целевой группы, игнорируем.")
        return

    # Получаем исходное сообщение
    original_message = update.message.reply_to_message

    # Проверяем, что ответ направлен на сообщение бота
    if original_message.from_user.id != context.bot.id:
        logger.debug("Ответ не на сообщение бота, игнорируем.")
        return

    # Игнорируем ответы на сообщения с созданием топика
    if getattr(original_message, "forum_topic_created", None) is not None:
        logger.debug("Ответ на сообщение о создании топика, игнорируем.")
        return

    # Получаем информацию о топике
    thread_id = original_message.message_thread_id
    if thread_id not in topic_to_user:
        logger.warning(f"Топик {thread_id} не найден в словаре.")
        return

    user_id = topic_to_user[thread_id]

    try:
        # Используем словарь для связи сообщений
        message_map = context.bot_data.setdefault("message_map", {})

        # Отправка текста
        if update.message.text:
            sent = await context.bot.send_message(
                chat_id=user_id,
                text=update.message.text,
                reply_to_message_id=message_map.get(original_message.message_id)
            )
            sent_types.append("текст")

        # Отправка медиафайлов (включая стикеры)
        media_handlers = [
            ("animation", "send_animation", update.message.animation),
            ("photo", "send_photo", update.message.photo[-1] if update.message.photo else None),
            ("video", "send_video", update.message.video),
            ("audio", "send_audio", update.message.audio),
            ("voice", "send_voice", update.message.voice),
            ("document", "send_document", update.message.document),
            ("sticker", "send_sticker", update.message.sticker)
        ]

        # Обрабатываем только первый подходящий тип медиа
        for media_type, method_name, file_obj in media_handlers:
            if file_obj:
                method = getattr(context.bot, method_name)
                try:
                    # Формируем параметры
                    kwargs = {
                        "chat_id": user_id,
                        media_type: file_obj.file_id,
                        "reply_to_message_id": message_map.get(original_message.message_id)
                    }

                    # Добавляем caption только для поддерживающих типов
                    if media_type not in {"sticker", "voice", "audio"}:
                        kwargs["caption"] = update.message.caption

                    sent = await method(**kwargs)
                    sent_types.append(media_type)
                    break  # Прерываем цикл после первой успешной отправки

                except Exception as e:
                    logger.error(f"Ошибка отправки {media_type}: {str(e)}")

        # Сохраняем связь сообщений
        if sent:
            message_map[update.message.message_id] = sent.message_id

        logger.info(f"Отправлено: {', '.join(sent_types)} пользователю {user_id}")

    except Exception as e:
        logger.error(f"Ошибка отправки: {str(e)}", exc_info=True)
        await update.message.reply_text("❌ Ошибка пересылки сообщения")
        success = False

    finally:
        if success and sent:
            try:
                await update.message.set_reaction([ReactionTypeEmoji("✅")])
            except Exception as e:
                logger.warning(f"Ошибка реакции: {str(e)}")