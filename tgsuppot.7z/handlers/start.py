from telegram import Update
from telegram.ext import ContextTypes
from globals.config import GROUP_CHAT_ID
from loger.logger import logger
from database import pool

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    username = update.effective_user.username or f"User {user_id}"

    async with pool.acquire() as conn:
        exists = await conn.fetchval(
            "SELECT 1 FROM users WHERE user_id = $1", user_id
        )
        
        if exists:
            await update.message.reply_text("Упс T_T! Что-то пошло не так. Повтори сообщение :)")
            logger.warning(f"Пользователь {username} (ID: {user_id}) уже имеет топик.")
            return

        try:
            chat = await context.bot.get_chat(GROUP_CHAT_ID)
            topic = await chat.create_forum_topic(name=f"Топик для {username}")
            
            await conn.execute(
                "INSERT INTO users (user_id, username, thread_id) VALUES ($1, $2, $3)",
                user_id, username, topic.message_thread_id
            )
            
            await update.message.reply_text("Привет! Я с радостью отвечу на все твои вопросы :)")
            logger.info(f"Создан топик для {username} (ID: {user_id})")
            
        except Exception as e:
            logger.error(f"Ошибка при создании топика: {e}")
            await update.message.reply_text("Не удалось отправить сообщение. Попробуйте позже.")