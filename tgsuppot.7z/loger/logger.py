import logging
from pathlib import Path
import sys

# Создаем папку для логов
Path("logs").mkdir(exist_ok=True, mode=0o777)

# Основной логгер
logger = logging.getLogger("Bot")
logger.setLevel(logging.DEBUG)

# Форматтер без микросекунд
formatter = logging.Formatter(
    "%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S"
)

# Обработчики для всех уровней
handlers = {
    "all": logging.FileHandler("logs/bot.log"),
}

# Настройка обработчиков
for handler in handlers.values():
    handler.setFormatter(formatter)
    logger.addHandler(handler)

# Включаем логирование для Telegram и HTTP-библиотек
for lib in [
    "telegram.ext", 
    "telegram.bot",
    "httpcore",
    "httpx",
    "httpcore.http11",
    "httpcore.connection"
]:
    lib_logger = logging.getLogger(lib)
    lib_logger.setLevel(logging.DEBUG)
    for handler in handlers.values():
        lib_logger.addHandler(handler)
    lib_logger.propagate = False  # Отключаем дублирование

# Отключаем стандартный логгер библиотеки telegram
logging.getLogger("telegram").propagate = False

# Отключение дублирования для библиотек
for lib in ["telegram", "httpcore", "httpx"]:
    logging.getLogger(lib).propagate = False  # Блокируем передачу логов выше

# Настройка логирования для компонентов Telegram
for component in ["ext", "bot", "application"]:
    tg_logger = logging.getLogger(f"telegram.{component}")
    tg_logger.setLevel(logging.DEBUG)
    for handler in handlers.values():
        tg_logger.addHandler(handler)
    tg_logger.propagate = False  # Дополнительная страховка

# Консольный вывод для отладки (опционально)
console_handler = logging.StreamHandler(sys.stdout)
console_handler.setLevel(logging.DEBUG)
console_handler.setFormatter(formatter)
logger.addHandler(console_handler)